Supporting image files for the git repo.
Blues logo created by Nathan Lim.
